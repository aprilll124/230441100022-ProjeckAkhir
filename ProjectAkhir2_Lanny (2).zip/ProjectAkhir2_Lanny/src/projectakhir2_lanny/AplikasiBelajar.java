/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhir2_lanny;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lanny aprilia
 */
public class AplikasiBelajar extends javax.swing.JFrame {

    /**
     * Creates new form AplikasiBelajar
     */
    Connection conn;
    private DefaultTableModel model;
    private Map<String, String> jenjangMap = new HashMap<>();
    private Map<String, String> mapelMap = new HashMap<>();
    private Map<String, String> materiMap = new HashMap<>();

    
    public AplikasiBelajar() {
        conn = koneksi.getConnection();
        initComponents();
        
        model = new DefaultTableModel();
        tbl_SG.setModel(model);

        model.addColumn("Username");
        model.addColumn("Materi");
        model.addColumn("ID");
        
        tbl_SG.getColumnModel().getColumn(2).setMinWidth(0);
        tbl_SG.getColumnModel().getColumn(2).setMaxWidth(0);
        tbl_SG.getColumnModel().getColumn(2).setWidth(0);
        
        loadJenjang();
        loadDataSG();
        autoklik();
        
        cmb_mapel.setEnabled(false); 
        cmb_materi.setEnabled(false); 

        cmb_jenjang2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (cmb_jenjang2.getSelectedIndex() != -1) {
                    loadMapel(cmb_jenjang2.getSelectedItem().toString());
                    cmb_mapel.setEnabled(true);
                }
            }
        });

        cmb_mapel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (cmb_mapel.getSelectedIndex() != -1) {
                    loadMateri(cmb_mapel.getSelectedItem().toString());
                    cmb_materi.setEnabled(true); 
                }
            }
        });    
    }
    
    private void autoklik() {
    tbl_SG.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) {
            int selectedRow = tbl_SG.getSelectedRow();
            if (selectedRow != -1) {
 
                String username = tbl_SG.getValueAt(selectedRow, 0).toString();
                String judulMateri = tbl_SG.getValueAt(selectedRow, 1).toString();
                Object goalIdObj = tbl_SG.getValueAt(selectedRow, 2);  

                if (goalIdObj != null) {
                    String goalId = goalIdObj.toString();
                    try {
                        String sql = "SELECT sg.goal_id, sg.username, m.judul_materi " +
                                     "FROM study_goals sg " +
                                     "JOIN materi m ON sg.materi_id = m.materi_id " +
                                     "WHERE sg.goal_id = ?";
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setString(1, goalId);
                        ResultSet rs = ps.executeQuery();

                        if (rs.next()) {
                            tf_username.setText(rs.getString("username"));
                            loadJenjang(); 
                            loadMapel(getSelectedJenjang()); 
                            loadMateri(getSelectedMapel()); 
                            cmb_materi.setSelectedItem(rs.getString("judul_materi"));
                        } else {
                            JOptionPane.showMessageDialog(this, "Data tidak ditemukan untuk goal_id: " + goalId);
                        }
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Error saat mengakses database: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "goal_id tidak ditemukan.");
                }
            }
        }
    });
}


    //TAB DUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

    private String getSelectedJenjang() {
        return (String) cmb_jenjang2.getSelectedItem();
    }
    
    private void loadJenjang() {
        cmb_jenjang2.removeAllItems();
        cmb_jenjang2.addItem("-Pilih Jenjang-");
        jenjangMap.clear();  

        try {
            String sql = "SELECT DISTINCT jenjang FROM mata_pelajaran";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String jenjang = rs.getString("jenjang");
                cmb_jenjang2.addItem(jenjang);
                jenjangMap.put(jenjang, jenjang);  
            }
        } catch (SQLException e) {
            System.out.println("Error loading jenjang: " + e.getMessage());
        }
    }


    private String getSelectedMapel() {
        return (String) cmb_mapel.getSelectedItem();
    }
    
    private void loadMapel(String jenjang) {
        cmb_mapel.removeAllItems();
        cmb_mapel.addItem("-Pilih Mata Pelajaran-");
        mapelMap.clear();  

        try {
            String sql = "SELECT nama_mapel FROM mata_pelajaran WHERE jenjang = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, jenjang);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String mapel = rs.getString("nama_mapel");
                cmb_mapel.addItem(mapel);
                mapelMap.put(mapel, mapel); 
            }
        } catch (SQLException e) {
            System.out.println("Error loading mapel: " + e.getMessage());
        }
    }
    

    private void loadMateri(String mapel) {
        cmb_materi.removeAllItems();
        cmb_materi.addItem("-Pilih Materi-");
        materiMap.clear();  // Menghapus data materi sebelumnya

        try {
            String sql = "SELECT m.materi_id, m.judul_materi " +
                         "FROM materi m " +
                         "JOIN mata_pelajaran mp ON m.mapel_id = mp.mapel_id " +
                         "WHERE mp.nama_mapel = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, mapel);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String materiId = rs.getString("materi_id");
                String judulMateri = rs.getString("judul_materi");

                cmb_materi.addItem(judulMateri); 
                materiMap.put(judulMateri, materiId); 
            }
        } catch (SQLException e) {
            System.out.println("Error loading materi: " + e.getMessage());
        }
    }


    //CRUDDDDDDDDDDDDDDD
    
    private void loadDataSG() {
    model.setRowCount(0);  

    try {
        String sql = "SELECT sg.goal_id, sg.username, mp.jenjang, mp.nama_mapel, m.judul_materi " +
                     "FROM study_goals sg " +
                     "JOIN materi m ON sg.materi_id = m.materi_id " +
                     "JOIN mata_pelajaran mp ON m.mapel_id = mp.mapel_id";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{ 
                rs.getString("username"),
                rs.getString("judul_materi"),
                rs.getString("goal_id"),
            });
        }
    } catch (SQLException e) {
        System.out.println("Error loading Data for Study Goals: " + e.getMessage());
    }
}


    
    //Simpan Data
    private void saveDataSG() {
        try {                  
            if (tf_username.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username harus diisi terlebih dahulu!");
                return;
            }

            String checkUsernameSql = "SELECT COUNT(*) FROM tb_pengguna WHERE username = ?";  // Gantilah 'users' dengan nama tabel yang sesuai
            PreparedStatement checkUsernamePs = conn.prepareStatement(checkUsernameSql);
            checkUsernamePs.setString(1, tf_username.getText());  
            ResultSet usernameRs = checkUsernamePs.executeQuery();
            usernameRs.next();

            if (usernameRs.getInt(1) == 0) {
                JOptionPane.showMessageDialog(this, "Username tidak ditemukan. Periksa kembali.");
                return;
            }

            if (cmb_jenjang2.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Jenjang harus dipilih terlebih dahulu!");
                return;
            }

            if (cmb_mapel.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Mata Pelajaran harus dipilih terlebih dahulu!");
                return;
            }

            if (cmb_materi.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Materi harus dipilih terlebih dahulu!");
                return;
            }

            String materiId = materiMap.get(cmb_materi.getSelectedItem());

            String checkSql = "SELECT COUNT(*) FROM study_goals WHERE username = ? AND materi_id = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, tf_username.getText());  
            checkPs.setString(2, materiId);  
            ResultSet rs = checkPs.executeQuery();
            rs.next();

            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(this, "Data sudah ada di database!");
                return;
            }

            String sql = "INSERT INTO study_goals (username, materi_id) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_username.getText());  
            ps.setString(2, materiId);  
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data saved successfully");
            loadDataSG();  
        } catch (SQLException e) {
            System.out.println("Error Save Study Goal: " + e.getMessage());
        }
    }
    
    //Update Data
    private void updateDataSG() {
        try {
            if (tf_username.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username harus diisi terlebih dahulu!");
                return;
            }

            String checkUsernameSql = "SELECT COUNT(*) FROM tb_pengguna WHERE username = ?";  // Gantilah 'tb_pengguna' dengan nama tabel yang sesuai
            PreparedStatement checkUsernamePs = conn.prepareStatement(checkUsernameSql);
            checkUsernamePs.setString(1, tf_username.getText());
            ResultSet usernameRs = checkUsernamePs.executeQuery();
            usernameRs.next();

            if (usernameRs.getInt(1) == 0) {
                JOptionPane.showMessageDialog(this, "Username tidak ditemukan. Periksa kembali.");
                return;
            }

            // Validasi apakah jenjang, mapel, dan materi dipilih
            if (cmb_jenjang2.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Jenjang harus dipilih terlebih dahulu!");
                return;
            }

            if (cmb_mapel.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Mata Pelajaran harus dipilih terlebih dahulu!");
                return;
            }

            if (cmb_materi.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Materi harus dipilih terlebih dahulu!");
                return;
            }

            String materiId = materiMap.get(cmb_materi.getSelectedItem());

            int selectedRow = tbl_SG.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Silakan pilih data yang ingin diupdate!");
                return;
            }

            String goalId = tbl_SG.getValueAt(selectedRow, 2).toString();  // Ambil goal_id dari kolom ke-3 (yang tersembunyi)

            String checkGoalIdSql = "SELECT COUNT(*) FROM study_goals WHERE goal_id = ?";
            PreparedStatement checkGoalIdPs = conn.prepareStatement(checkGoalIdSql);
            checkGoalIdPs.setString(1, goalId);
            ResultSet checkGoalIdRs = checkGoalIdPs.executeQuery();
            checkGoalIdRs.next();

            if (checkGoalIdRs.getInt(1) == 0) {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan untuk goal_id: " + goalId);
                return;
            }

            String sqlUpdate = "UPDATE study_goals SET username = ?, materi_id = ? WHERE goal_id = ?";
            PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
            psUpdate.setString(1, tf_username.getText());  
            psUpdate.setString(2, materiId); 
            psUpdate.setString(3, goalId);  
            int rowsUpdated = psUpdate.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil diperbarui.");
                loadDataSG(); 
            } else {
                JOptionPane.showMessageDialog(this, "Update gagal, data tidak ditemukan.");
            }

        } catch (SQLException e) {
            System.out.println("Error Update Study Goal: " + e.getMessage());
        }
    }
    
    //Delete Data
    private void deleteDataSG() {
        try {
            int selectedRow = tbl_SG.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Silakan pilih data yang ingin dihapus!");
                return;
            }

            String goalId = tbl_SG.getValueAt(selectedRow, 2).toString();

            String checkGoalIdSql = "SELECT COUNT(*) FROM study_goals WHERE goal_id = ?";
            PreparedStatement checkGoalIdPs = conn.prepareStatement(checkGoalIdSql);
            checkGoalIdPs.setString(1, goalId);
            ResultSet checkGoalIdRs = checkGoalIdPs.executeQuery();
            checkGoalIdRs.next();

            if (checkGoalIdRs.getInt(1) == 0) {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan untuk goal_id: " + goalId);
                return;
            }

            String sqlDelete = "DELETE FROM study_goals WHERE goal_id = ?";
            PreparedStatement psDelete = conn.prepareStatement(sqlDelete);
            psDelete.setString(1, goalId);
            int rowsDeleted = psDelete.executeUpdate();

            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");
                loadDataSG();  
            } else {
                JOptionPane.showMessageDialog(this, "Hapus data gagal.");
            }

        } catch (SQLException e) {
            System.out.println("Error Delete Study Goal: " + e.getMessage());
        }
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TabbedPane = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        cmb_jenjang1 = new javax.swing.JComboBox<>();
        chb_biologi1 = new javax.swing.JCheckBox();
        chb_bindonesia1 = new javax.swing.JCheckBox();
        chb_binggris1 = new javax.swing.JCheckBox();
        chb_fisika1 = new javax.swing.JCheckBox();
        chb_kimia1 = new javax.swing.JCheckBox();
        chb_ips1 = new javax.swing.JCheckBox();
        chb_matematika1 = new javax.swing.JCheckBox();
        chb_ipa1 = new javax.swing.JCheckBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        Logout = new javax.swing.JCheckBox();
        jLabel12 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        tf_username = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        btnSave = new javax.swing.JButton();
        btn_signup4 = new javax.swing.JButton();
        cmb_mapel = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        cmb_materi = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_SG = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        cmb_jenjang2 = new javax.swing.JComboBox<>();
        btn_delete = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 153, 153));

        TabbedPane.setBackground(new java.awt.Color(255, 204, 204));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, -1, -1));

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cmb_jenjang1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "----- PILIH JENJANG -----", "SMP", "SMA" }));
        cmb_jenjang1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_jenjang1ActionPerformed(evt);
            }
        });
        jPanel8.add(cmb_jenjang1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 310, -1));

        chb_biologi1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_biologi1.setText("   BIOLOGI");
        chb_biologi1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\bio3.png")); // NOI18N
        chb_biologi1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_biologi1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_biologi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 300, 260, 70));

        chb_bindonesia1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_bindonesia1.setText(" BAHASA INDONESIA");
        chb_bindonesia1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\BI8.png")); // NOI18N
        chb_bindonesia1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_bindonesia1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_bindonesia1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 240, 80));

        chb_binggris1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_binggris1.setText("  BAHASA INGGRIS");
        chb_binggris1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\english4.png")); // NOI18N
        chb_binggris1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_binggris1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_binggris1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 240, 70));

        chb_fisika1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_fisika1.setText("  FISIKA");
        chb_fisika1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\fisika2.png")); // NOI18N
        chb_fisika1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_fisika1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_fisika1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 270, 80));

        chb_kimia1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_kimia1.setText("  KIMIA");
        chb_kimia1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\kimia2.png")); // NOI18N
        jPanel8.add(chb_kimia1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 380, 240, 70));

        chb_ips1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_ips1.setText("  ILMU PENGETAHUAN SOSIAL");
        chb_ips1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\ips2.png")); // NOI18N
        chb_ips1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_ips1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_ips1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 220, 270, 70));

        chb_matematika1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_matematika1.setText(" MATEMATIKA");
        chb_matematika1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\mtk3.png")); // NOI18N
        chb_matematika1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_matematika1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_matematika1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 270, 70));

        chb_ipa1.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        chb_ipa1.setText("ILMU PENGETAHUAN ALAM");
        chb_ipa1.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\ipa5.png")); // NOI18N
        chb_ipa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chb_ipa1ActionPerformed(evt);
            }
        });
        jPanel8.add(chb_ipa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 140, 270, 70));

        jLabel13.setFont(new java.awt.Font("Script MT Bold", 0, 27)); // NOI18N
        jLabel13.setText("Mau Belajar");
        jPanel8.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, -1, -1));

        jLabel14.setFont(new java.awt.Font("Script MT Bold", 0, 27)); // NOI18N
        jLabel14.setText("Apa Hari Ini?");
        jPanel8.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, 190, -1));

        jPanel6.setBackground(new java.awt.Color(239, 206, 173));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Logout.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        Logout.setForeground(new java.awt.Color(102, 0, 0));
        Logout.setText("Logout");
        Logout.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\logout5.png")); // NOI18N
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        jPanel6.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jPanel8.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 670, 60));

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\base12.jpg")); // NOI18N
        jPanel8.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 680, 490));

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        TabbedPane.addTab("Home", jPanel2);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(255, 255, 255, 180));

        jLabel17.setFont(new java.awt.Font("NSimSun", 1, 24)); // NOI18N
        jLabel17.setText("Ayo Belajar");

        jLabel18.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel18.setText("Username");

        jLabel19.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel19.setText("Mata Pelajaran");

        btnSave.setBackground(new java.awt.Color(153, 153, 0));
        btnSave.setText("Creat");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btn_signup4.setBackground(new java.awt.Color(153, 153, 0));
        btn_signup4.setText("Update");
        btn_signup4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_signup4ActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel22.setText("Materi");

        tbl_SG.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_SG.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_SGMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_SG);

        jLabel20.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel20.setText("Jenjang");

        btn_delete.setBackground(new java.awt.Color(153, 153, 0));
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(231, 231, 231))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1)
                .addGap(19, 19, 19))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addComponent(btnSave)
                .addGap(79, 79, 79)
                .addComponent(btn_signup4)
                .addGap(73, 73, 73)
                .addComponent(btn_delete)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap(67, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(tf_username, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cmb_jenjang2, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_mapel, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_materi, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmb_jenjang2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmb_mapel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmb_materi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSave)
                    .addComponent(btn_signup4)
                    .addComponent(btn_delete))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 640, 460));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\lanny aprilia\\Downloads\\bekgron2.jpg")); // NOI18N
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 680, 510));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 110, -1, -1));

        TabbedPane.addTab("Study Goals", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 662, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TabbedPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void chb_matematika1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_matematika1ActionPerformed
        if (chb_matematika1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_matematika1.setSelected(false); 
            } else {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);
              
                    if (cmb_jenjang1.getSelectedIndex() == 1) {
                        new materi_matematika_smp().setVisible(true); 
                    } else if (cmb_jenjang1.getSelectedIndex() == 2) {
                        new materi_matematika_sma().setVisible(true); 
                    }
                } else {
                    chb_matematika1.setSelected(false); 
                }
            }
        }
    }//GEN-LAST:event_chb_matematika1ActionPerformed

    private void chb_ips1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_ips1ActionPerformed
        if (chb_ips1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_ips1.setSelected(false); 
            } else if (cmb_jenjang1.getSelectedIndex() == 1) {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);
                    new materi_ips_smp().setVisible(true); 
                } else {
                    chb_ips1.setSelected(false); 
                }
            }
        }

    }//GEN-LAST:event_chb_ips1ActionPerformed

    private void chb_ipa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_ipa1ActionPerformed
        if (chb_ipa1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_ipa1.setSelected(false); 
            } else if (cmb_jenjang1.getSelectedIndex() == 1) {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);
                    new materi_ipa_smp().setVisible(true); 
                } else {
                    chb_ipa1.setSelected(false); 
                }
            }
        }
    }//GEN-LAST:event_chb_ipa1ActionPerformed

    private void cmb_jenjang1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_jenjang1ActionPerformed
        int selectedIndex = cmb_jenjang1.getSelectedIndex();

        if (selectedIndex == 0) {
            JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
        } else {
            chb_matematika1.setVisible(false);
            chb_bindonesia1.setVisible(false);
            chb_binggris1.setVisible(false);
            chb_ipa1.setVisible(false);
            chb_ips1.setVisible(false);
            chb_kimia1.setVisible(false);
            chb_fisika1.setVisible(false);
            chb_biologi1.setVisible(false);

            if (selectedIndex == 1) {
                chb_matematika1.setVisible(true);
                chb_bindonesia1.setVisible(true);
                chb_binggris1.setVisible(true);
                chb_ipa1.setVisible(true);
                chb_ips1.setVisible(true);
            } else if (selectedIndex == 2) {
                chb_matematika1.setVisible(true);
                chb_bindonesia1.setVisible(true);
                chb_binggris1.setVisible(true);
                chb_kimia1.setVisible(true);
                chb_fisika1.setVisible(true);
                chb_biologi1.setVisible(true);
            }
        }

        ItemListener checkBoxListener = e -> {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                ((JCheckBox) e.getSource()).setSelected(false); 
            }
        };

        chb_matematika1.addItemListener(checkBoxListener);
        chb_bindonesia1.addItemListener(checkBoxListener);
        chb_binggris1.addItemListener(checkBoxListener);
        chb_ipa1.addItemListener(checkBoxListener);
        chb_ips1.addItemListener(checkBoxListener);
        chb_kimia1.addItemListener(checkBoxListener);
        chb_fisika1.addItemListener(checkBoxListener);
        chb_biologi1.addItemListener(checkBoxListener);

    }//GEN-LAST:event_cmb_jenjang1ActionPerformed

    private void chb_bindonesia1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_bindonesia1ActionPerformed
        if (chb_bindonesia1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_bindonesia1.setSelected(false); 
            } else {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);
                    if (cmb_jenjang1.getSelectedIndex() == 1) {
                        new materi_bindonesia_smp().setVisible(true);
                    } else if (cmb_jenjang1.getSelectedIndex() == 2) {
                        new materi_bindonesia_sma().setVisible(true); 
                    }
                } else {
                    chb_bindonesia1.setSelected(false); 
                }
            }
        }
    }//GEN-LAST:event_chb_bindonesia1ActionPerformed
    

    


    
    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        saveDataSG();
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btn_signup4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_signup4ActionPerformed
        updateDataSG();
    }//GEN-LAST:event_btn_signup4ActionPerformed

    private void chb_binggris1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_binggris1ActionPerformed
        if (chb_binggris1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_binggris1.setSelected(false); 
            } else {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);

                    if (cmb_jenjang1.getSelectedIndex() == 1) {
                        new materi_binggris_smp().setVisible(true); 
                    } else if (cmb_jenjang1.getSelectedIndex() == 2) {
                        new materi_binggris_sma().setVisible(true); 
                    }
                } else {
                    chb_binggris1.setSelected(false); 
                }
            }
        }
    }//GEN-LAST:event_chb_binggris1ActionPerformed

    private void chb_biologi1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_biologi1ActionPerformed
        if (chb_biologi1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_biologi1.setSelected(false); 
            } else if (cmb_jenjang1.getSelectedIndex() == 2) {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);
                    new materi_biologi_sma().setVisible(true); 
                } else {
                    chb_biologi1.setSelected(false); 
                }
            }
        }
    }//GEN-LAST:event_chb_biologi1ActionPerformed

    private void chb_fisika1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chb_fisika1ActionPerformed
        if (chb_fisika1.isSelected()) {
            if (cmb_jenjang1.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Harap pilih jenjang terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                chb_fisika1.setSelected(false); 
            } else if (cmb_jenjang1.getSelectedIndex() == 2) {
                int option = JOptionPane.showConfirmDialog(
                        this,
                        "Anda akan diarahkan ke halaman materi. Apakah Anda yakin?",
                        "Konfirmasi",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (option == JOptionPane.YES_OPTION) {
                    this.setVisible(false);
                    new materi_fisika_sma().setVisible(true);
                } else {
                    chb_fisika1.setSelected(false); 
                }
            }
        }
    }//GEN-LAST:event_chb_fisika1ActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        this.dispose();  

        Login loginForm = new Login();  
        loginForm.setVisible(true);

    }//GEN-LAST:event_LogoutActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        deleteDataSG();
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void tbl_SGMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_SGMouseClicked
        
    }//GEN-LAST:event_tbl_SGMouseClicked

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AplikasiBelajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AplikasiBelajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AplikasiBelajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AplikasiBelajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AplikasiBelajar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Logout;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_signup4;
    private javax.swing.JCheckBox chb_bindonesia1;
    private javax.swing.JCheckBox chb_binggris1;
    private javax.swing.JCheckBox chb_biologi1;
    private javax.swing.JCheckBox chb_fisika1;
    private javax.swing.JCheckBox chb_ipa1;
    private javax.swing.JCheckBox chb_ips1;
    private javax.swing.JCheckBox chb_kimia1;
    private javax.swing.JCheckBox chb_matematika1;
    private javax.swing.JComboBox<String> cmb_jenjang1;
    private javax.swing.JComboBox<String> cmb_jenjang2;
    private javax.swing.JComboBox<String> cmb_mapel;
    private javax.swing.JComboBox<String> cmb_materi;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_SG;
    private javax.swing.JTextField tf_username;
    // End of variables declaration//GEN-END:variables
}
